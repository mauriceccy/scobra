def sumsquare(number):
    s=0
    for i in range (number):
        s+=i * i
    return s