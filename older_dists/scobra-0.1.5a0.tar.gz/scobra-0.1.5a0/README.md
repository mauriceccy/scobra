# scobra

scobra is a supplementary package for COBRApy designed by Maurice Cheung used by the Yale-NUS Computational and Systems Biology group. This version is specifically for Python 3.6 and above.

To install scobra, run this line:
```
pip install scobra
```
